CAITLIN CURATES - FINAL WEBSITE PHASE

FILES
- index.html: main website, culinary gallery, JavaScript interactions and booking form.
- booking-success.html: separate thank-you page after a successful booking submission.

HOW TO OPEN IN VISUAL STUDIO CODE
1. Create/open a folder named Caitlin-Curates.
2. Put index.html and booking-success.html in that folder.
3. Put the food images in the same folder. Use these exact filenames (or update the image src values in index.html):
   PICURE 1.jpeg
   picture 8.jpeg
   mince artwork.jpeg
   lamb dish.jpeg
   cake strawberry.jpeg
   cinnamon rolls.jpeg
   MUFFINS.jpeg
4. Open index.html with the VS Code Live Server extension.

FUNCTIONAL BOOKING FORM
- The form checks required fields, email format, phone format, guest count and booking date in the browser.
- A successful FormSubmit response redirects the visitor to booking-success.html.
- Booking enquiries are addressed to Caitlincurates@gmail.com through FormSubmit.
- The first submission may require the owner to confirm/activate the FormSubmit email address. Check the inbox and spam folder for its activation email.
- The site needs an internet connection for FormSubmit and Google Fonts.
- Test email delivery after publishing the website online. The redirect uses the relative page booking-success.html, so keep both HTML files together in the same published folder.

JAVASCRIPT FEATURES
- Scroll reveal animations (disabled for visitors who prefer reduced motion).
- Click-to-enlarge gallery lightbox with Escape-key closing.
- Automatically updated copyright year.
- Booking form validation and asynchronous submission status.

SEO FEATURES
- Descriptive page title and meta description.
- Relevant meta keywords and robots directive.
- Open Graph sharing metadata.
- Structured data describing the culinary business.
- Descriptive image alt text, semantic headings and lazy-loaded gallery images.

GALLERY MANAGEMENT
The gallery is owner-managed. Visitors can view and enlarge images, but there is no public image-upload form. To add a picture, place the image in the website folder and add another gallery item in index.html.
